import { raceClock } from '../../services/raceClock';
import React, { useEffect, useState } from 'react';
import './LiveLeaderboardView.css';
import {
  Trophy,
  Search,
  Filter,
  Medal,
  Tv,
  Lock,
  Download,
  Share2,
  Crosshair,
  Flag,
  Settings,
  Clock,
} from 'lucide-react';
import type { RaceResult, Category, Wave, RaceEvent, ParticipantStatus } from '../../types';
import { formatDuration } from '../../services/timingEngine';
import { downloadCsvFile } from '../../services/backupService';

interface LiveLeaderboardViewProps {
  results: RaceResult[];
  categories: Category[];
  waves: Wave[];
  event: RaceEvent | null;
  mode?: 'live' | 'results';
  onSelectParticipant: (result: RaceResult) => void;
  onKioskModeChange?: (isKioskMode: boolean) => void;
}

interface TvKioskConfig {
  showPodium: boolean;
  showClock: boolean;
  rotateCategories: boolean;
  categoryIds: string[];
  rotationSeconds: number;
  textScale: 'normal' | 'large' | 'extra-large';
}

const defaultTvKioskConfig: TvKioskConfig = {
  showPodium: true,
  showClock: true,
  rotateCategories: false,
  categoryIds: [],
  rotationSeconds: 15,
  textScale: 'large',
};

export const LiveLeaderboardView: React.FC<LiveLeaderboardViewProps> = ({
  results,
  categories,
  waves,
  event,
  mode = 'live',
  onSelectParticipant,
  onKioskModeChange,
}) => {
  const kioskStorageKey = `biathlon_tv_kiosk_config:${event?.id || 'new'}`;
  const profileOptions = [...new Map(results.map(r => [r.raceProfileId ?? '', r.raceProfileName ?? 'Nog niet gekoppeld'])).entries()];
  const [selectedProfile, setSelectedProfile] = useState('__default');
  const activeProfile = profileOptions.some(([id]) => id === selectedProfile) ? selectedProfile : profileOptions.find(([id]) => !!id)?.[0] ?? '';
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedWave, setSelectedWave] = useState<string>('ALL');
  const [selectedGender, setSelectedGender] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | ParticipantStatus>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isKioskMode, setIsKioskMode] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState(() => new Date(raceClock.nowMs()));
  const [showKioskSettings, setShowKioskSettings] = useState(false);
  const [tvConfig, setTvConfig] = useState<TvKioskConfig>(() => {
    try {
      const storedConfig = JSON.parse(localStorage.getItem(kioskStorageKey) || '{}');
      return {
        ...defaultTvKioskConfig,
        showPodium: storedConfig.showPodium !== false,
        showClock: storedConfig.showClock !== false,
        rotateCategories: storedConfig.rotateCategories === true,
        rotationSeconds: [10, 15, 30, 60].includes(storedConfig.rotationSeconds) ? storedConfig.rotationSeconds : 15,
        categoryIds: Array.isArray(storedConfig.categoryIds) ? storedConfig.categoryIds : [],
        textScale: ['normal', 'large', 'extra-large'].includes(storedConfig.textScale) ? storedConfig.textScale : defaultTvKioskConfig.textScale,
      };
    } catch {
      return defaultTvKioskConfig;
    }
  });

  const availableCategoryIds = categories.filter(c => results.some(r => (r.raceProfileId ?? '') === activeProfile && r.categoryId === c.id && (selectedWave === 'ALL' || r.waveId === selectedWave) && (selectedGender === 'ALL' || r.gender === selectedGender))).map(c => c.id);
  const configuredCategoryIds = tvConfig.categoryIds.filter((id) => availableCategoryIds.includes(id));
  const rotationCategoryIds = configuredCategoryIds.length === 0 ? availableCategoryIds : configuredCategoryIds;
  const rotationCategoryKey = rotationCategoryIds.join('|');

  useEffect(() => {
    try { localStorage.setItem(kioskStorageKey, JSON.stringify(tvConfig)); } catch { /* Kiosk remains usable if browser storage is unavailable. */ }
  }, [tvConfig, kioskStorageKey]);

  useEffect(() => {
    onKioskModeChange?.(isKioskMode);
  }, [isKioskMode, onKioskModeChange]);

  useEffect(() => () => onKioskModeChange?.(false), [onKioskModeChange]);

  useEffect(() => {
    const handleFullscreenChange = () => {
      if (!document.fullscreenElement) { setIsKioskMode(false); setShowKioskSettings(false); }
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  useEffect(() => {
    const escape = (e: KeyboardEvent) => { if (e.key === 'Escape' && !document.fullscreenElement) { setIsKioskMode(false); setShowKioskSettings(false); } };
    window.addEventListener('keydown', escape);
    return () => window.removeEventListener('keydown', escape);
  }, []);

  const toggleKioskMode = async () => {
    if (isKioskMode) {
      if (document.fullscreenElement) await document.exitFullscreen?.();
      setIsKioskMode(false);
      setShowKioskSettings(false);
      return;
    }

    try {
      if (document.documentElement.requestFullscreen) {
        await document.documentElement.requestFullscreen();
        setIsKioskMode(true);
      } else {
        setIsKioskMode(true);
      }
    } catch {
      setIsKioskMode(true);
    }
  };

  useEffect(() => {
    if (!isKioskMode || !tvConfig.rotateCategories || rotationCategoryIds.length === 0) return;

    setSelectedCategory((current) => (
      rotationCategoryIds.includes(current) ? current : rotationCategoryIds[0]
    ));

    const rotation = window.setInterval(() => {
      setSelectedCategory((current) => {
        const currentIndex = rotationCategoryIds.indexOf(current);
        return rotationCategoryIds[(currentIndex + 1) % rotationCategoryIds.length];
      });
    }, Math.max(5, tvConfig.rotationSeconds) * 1000);
    return () => window.clearInterval(rotation);
  }, [isKioskMode, rotationCategoryKey, tvConfig.rotateCategories, tvConfig.rotationSeconds]);

  const toggleRotationCategory = (categoryId: string) => {
    setTvConfig((current) => {
      const selectedIds = current.categoryIds.length === 0
        ? availableCategoryIds
        : current.categoryIds.filter((id) => availableCategoryIds.includes(id));

      if (selectedIds.includes(categoryId) && selectedIds.length === 1) return current;

      const nextIds = selectedIds.includes(categoryId)
        ? selectedIds.filter((id) => id !== categoryId)
        : availableCategoryIds.filter((id) => selectedIds.includes(id) || id === categoryId);

      return {
        ...current,
        categoryIds: nextIds.length === availableCategoryIds.length ? [] : nextIds,
      };
    });
  };

  useEffect(() => {
    if (!isKioskMode || !tvConfig.showClock) return;
    const clock = window.setInterval(() => setCurrentTime(new Date(raceClock.nowMs())), 1000);
    return () => window.clearInterval(clock);
  }, [isKioskMode, tvConfig.showClock]);

  // Filter logic
  const filteredResults = results.filter((r) => {
    if ((r.raceProfileId ?? '') !== activeProfile) return false;
    if (selectedCategory !== 'ALL' && r.categoryId !== selectedCategory) return false;
    if (selectedWave !== 'ALL' && r.waveId !== selectedWave) return false;
    if (selectedGender !== 'ALL' && r.gender !== selectedGender) return false;
    if (statusFilter !== 'ALL' && r.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = r.name.toLowerCase().includes(q);
      const matchBib = String(r.bibNumber || '').includes(q);
      const matchClub = (r.club || '').toLowerCase().includes(q);
      if (!matchName && !matchBib && !matchClub) return false;
    }
    return true;
  });

  // Search and status only hide rows; category, wave and gender define the ranking.
  const ranked = results.filter(r => r.raceProfileId === activeProfile && r.rankOverall !== undefined &&
    (selectedCategory === 'ALL' || r.categoryId === selectedCategory) &&
    (selectedWave === 'ALL' || r.waveId === selectedWave) &&
    (selectedGender === 'ALL' || r.gender === selectedGender)).sort((a, b) => a.rankOverall! - b.rankOverall!);
  const ranks = new Map(ranked.map((r, index) => [r.participantId, index + 1]));
  const displayRank = (r: RaceResult) => ranks.get(r.participantId);
  const displayGap = (r: RaceResult) => displayRank(r) && ranked.length ? `+${formatDuration(r.officialTimeMs! - ranked[0].officialTimeMs!, true, false)}` : '';

  // Top 3 Podium finishers for the current filter
  const finishedPodium = filteredResults
    .filter((r) => r.status === 'FINISHED' && displayRank(r))
    .slice(0, 3);

  const handleExportCsv = () => {
    const headers =
      'Plaats,Startnummer,Naam,Club,Geslacht,Wedstrijdprofiel,Categorie,Wave,Starttijd,Finishtijd,Looptijd (Raw),Missers,Straftijd,Officiële Tijd,Verschil,Status\n';
    const rows = filteredResults.map((r) => {
      return `${displayRank(r) || ''},${r.bibNumber || ''},"${r.name}","${
        r.club || ''
      }",${r.gender || ''},"${r.raceProfileName || ''}","${r.categoryName || ''}","${r.waveName || ''}",${r.startTime || ''},${
        r.finishTime || ''
      },${r.rawElapsedFormatted || ''},${r.totalMisses || 0},${r.penaltyFormatted || ''},${
        r.officialTimeFormatted || ''
      },${displayGap(r) || ''},${r.status}`;
    });

    const csv = headers + rows.join('\n');
    downloadCsvFile(csv, `uitslagen_${Date.now()}.csv`);
  };

  return (
    <div data-text-scale={isKioskMode ? tvConfig.textScale : undefined} className={`space-y-6 text-xs ${isKioskMode ? 'leaderboard-kiosk p-3 sm:p-6 bg-slate-950 min-h-screen' : ''}`}>
      {/* Top Banner & TV Kiosk Mode Toggle */}
      <div className={isKioskMode
        ? 'flex flex-wrap items-center justify-between gap-3'
        : 'bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-wrap items-center justify-between gap-4'}>
        {!isKioskMode && <div>
          <div className="flex items-center gap-2 mb-1">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-mono uppercase tracking-widest text-amber-400 font-bold">
              {mode === 'results' ? 'Officiële Wedstrijduitslagen' : 'Live Wedstrijdbord (Realtime)'}
            </span>
            {event?.officialResultsLocked ? (
              <span className="text-[10px] bg-red-500/20 text-red-300 border border-red-500/30 px-2 py-0.5 rounded font-bold uppercase flex items-center gap-1">
                <Lock className="w-3 h-3" /> Officieel Vastgelegd
              </span>
            ) : (
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded font-bold uppercase">
                {mode === 'results' ? 'Voorlopige Uitslag' : 'Live Tussentijden'}
              </span>
            )}
          </div>
          <p className="text-amber-300 font-bold">{profileOptions.find(([id]) => id === activeProfile)?.[1]} · {selectedCategory === 'ALL' ? 'Alle leeftijdscategorieën' : categories.find(c => c.id === selectedCategory)?.name}</p>
          <h2 className="text-2xl font-black text-white tracking-tight">
            {event?.name || 'Nieuw evenement'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {mode === 'results'
              ? `Eindklassementen inclusief schietstraftijden (+${event?.penaltySecondsPerMiss || 20}s per misser) en categorie-podia`
              : `Realtime updates tijdens de race: actieve lopers op parcours, live schietbeurten en virtuele tussenstanden`}
          </p>
        </div>}
        {isKioskMode && <p className="text-lg text-amber-300 font-bold">{profileOptions.find(([id]) => id === activeProfile)?.[1]} · {selectedCategory === 'ALL' ? 'Alle leeftijdscategorieën' : categories.find(c => c.id === selectedCategory)?.name}</p>}

        <div className="flex items-center gap-2.5">
          {!isKioskMode && <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-medium transition"
          >
            <Download className="w-4 h-4" /> CSV Export
          </button>}
          {isKioskMode && (
            <button
              type="button"
              aria-expanded={showKioskSettings}
              aria-controls="kiosk-settings"
              onClick={() => setShowKioskSettings((current) => !current)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700 text-xs font-bold transition"
            >
              <Settings className="w-4 h-4" />
              <span>Instellingen</span>
            </button>
          )}
          <button
            onClick={toggleKioskMode}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
              isKioskMode
                ? 'bg-amber-500 text-slate-950'
                : 'bg-slate-800 text-slate-200 hover:bg-slate-750 border border-slate-700'
            }`}
          >
            <Tv className="w-4 h-4" />
            <span>{isKioskMode ? 'Kiosk verlaten' : 'TV Kiosk Modus'}</span>
          </button>
        </div>
      </div>

      {isKioskMode && showKioskSettings && (
        <div id="kiosk-settings" className="bg-slate-900 border border-amber-500/40 rounded-xl p-4 space-y-4 text-xs">
          <div className="flex flex-wrap items-center gap-4">
          <label className="flex items-center gap-2 text-slate-200">
            <input type="checkbox" checked={tvConfig.showPodium} onChange={(event) => setTvConfig({ ...tvConfig, showPodium: event.target.checked })} />
            Podium tonen
          </label>
          <label className="flex items-center gap-2 text-slate-200">
            <input type="checkbox" checked={tvConfig.showClock} onChange={(event) => setTvConfig({ ...tvConfig, showClock: event.target.checked })} />
            Klok tonen
          </label>
          <label className="flex items-center gap-2 text-slate-200">
            <input type="checkbox" checked={tvConfig.rotateCategories} onChange={(event) => setTvConfig({ ...tvConfig, rotateCategories: event.target.checked })} />
            Categorieën roteren
          </label>
          <label className="flex items-center gap-2 text-slate-200">
            Interval
            <select value={tvConfig.rotationSeconds} onChange={(event) => setTvConfig({ ...tvConfig, rotationSeconds: Number(event.target.value) })} className="bg-slate-800 border border-slate-700 rounded px-2 py-1">
              <option value={10}>10 sec.</option>
              <option value={15}>15 sec.</option>
              <option value={30}>30 sec.</option>
              <option value={60}>60 sec.</option>
            </select>
          </label>
          <label className="flex items-center gap-2 text-slate-200">
            Tekstgrootte
            <select aria-label="Tekstgrootte" value={tvConfig.textScale} onChange={(event) => setTvConfig({ ...tvConfig, textScale: event.target.value as TvKioskConfig['textScale'] })} className="bg-slate-800 border border-slate-700 rounded px-2 py-1">
              <option value="normal">Normaal</option>
              <option value="large">Groot</option>
              <option value="extra-large">Extra groot</option>
            </select>
          </label>
          </div>

          <fieldset className="border-t border-slate-800 pt-3">
            <div className="flex items-center justify-between gap-3 mb-2">
              <legend className="font-bold text-slate-200">Categorieën in de rotatie</legend>
              <button
                type="button"
                onClick={() => setTvConfig((current) => ({ ...current, categoryIds: [] }))}
                className="text-amber-300 hover:text-amber-200 font-semibold"
              >
                Alle selecteren
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {categories.filter(category => availableCategoryIds.includes(category.id)).map((category) => (
                <label key={`kiosk-category-${category.id}`} className="flex items-center gap-2 rounded-lg bg-slate-800/70 border border-slate-700 px-3 py-2 text-slate-200">
                  <input
                    type="checkbox"
                    checked={rotationCategoryIds.includes(category.id)}
                    onChange={() => toggleRotationCategory(category.id)}
                  />
                  <span>{category.name}</span>
                </label>
              ))}
            </div>
            {categories.length === 0 && <p className="text-slate-500">Er zijn nog geen categorieën ingesteld.</p>}
          </fieldset>
        </div>
      )}

      {isKioskMode && tvConfig.showClock && (
        <div className="flex items-center justify-end gap-2 text-amber-300 font-mono font-bold text-lg">
          <Clock className="w-5 h-5" />
          {currentTime.toLocaleTimeString('nl-BE', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
        </div>
      )}

      {/* Filter Toolbar */}
      <div role="region" aria-label="Scorebordfilters" className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow flex flex-wrap items-center gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            aria-label="Zoeken op naam, startnummer of club"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Zoek op naam, startnummer of club..."
            className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-500"
          />
        </div>

        <label className="text-xs">Wedstrijdprofiel
          <select aria-label="Wedstrijdprofiel" value={activeProfile} onChange={e => { setSelectedProfile(e.target.value); setSelectedCategory('ALL'); }} className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white ml-2">
            {profileOptions.map(([id, name]) => <option key={id} value={id}>{name}</option>)}
          </select>
        </label>
        {/* Category Filter */}
        <select
          aria-label="Leeftijdscategorie"
          value={selectedCategory}
          onChange={(e) => {
            setSelectedCategory(e.target.value);
            setTvConfig(current => ({ ...current, rotateCategories: false }));
          }}
          className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-medium focus:outline-none focus:border-amber-500"
        >
          <option value="ALL">Alle Categorieën ({categories.length})</option>
          {categories.map((c) => (
            <option key={`lb-cat-${c.id}`} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>

        {/* Wave Filter */}
        <select
          aria-label="Startgroep"
          value={selectedWave}
          onChange={(e) => setSelectedWave(e.target.value)}
          className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-medium focus:outline-none focus:border-amber-500"
        >
          <option value="ALL">Alle Waves ({waves.length})</option>
          {waves.map((w) => (
            <option key={`lb-wave-${w.id}`} value={w.id}>
              {w.name}
            </option>
          ))}
        </select>

        {/* Gender Filter */}
        <select
          aria-label="Geslacht"
          value={selectedGender}
          onChange={(e) => setSelectedGender(e.target.value)}
          className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-medium focus:outline-none focus:border-amber-500"
        >
          <option value="ALL">Geslacht (Alle)</option>
          <option value="M">Heren</option>
          <option value="F">Dames</option>
          <option value="X">Open / onbekend</option>
        </select>
        <select aria-label="Deelnemerstatus" value={statusFilter} onChange={e => setStatusFilter(e.target.value as typeof statusFilter)} className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white">
          <option value="ALL">Alle statussen</option>
          <option value="REGISTERED">Ingeschreven</option>
          <option value="CHECKED_IN">Aangemeld</option>
          <option value="READY">Klaar voor start</option>
          <option value="STARTED">Onderweg</option>
          <option value="FINISHED">Gefinisht</option>
          <option value="DNS">Niet gestart (DNS)</option>
          <option value="DNF">Niet gefinisht (DNF)</option>
          <option value="DSQ">Gediskwalificeerd (DSQ)</option>
        </select>
        {isKioskMode && tvConfig.rotateCategories && <p className="text-xs text-amber-300">Categorierotatie actief. Zelf een categorie kiezen stopt de rotatie.</p>}
      </div>

      {/* Podium Cards if finishes exist */}
      {tvConfig.showPodium && finishedPodium.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Silver #2 */}
          {finishedPodium[1] && (
            <div
              onClick={() => !isKioskMode && onSelectParticipant(finishedPodium[1])}
              className="bg-slate-900 border border-slate-750 hover:border-slate-600 rounded-2xl p-5 shadow cursor-pointer transition flex flex-col justify-between order-2 sm:order-1 relative overflow-hidden"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="w-9 h-9 rounded-xl bg-slate-300 text-slate-950 font-black text-base flex items-center justify-center shadow">
                  #2
                </span>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  ZILVER
                </span>
              </div>
              <div>
                <span className="text-lg font-bold text-white block">
                  {finishedPodium[1].name}
                </span>
                <span className="text-xs text-slate-400">
                  Bib #{finishedPodium[1].bibNumber} • {finishedPodium[1].categoryName}
                </span>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">
                  {finishedPodium[1].totalMisses} missers ({finishedPodium[1].penaltyFormatted})
                </span>
                <span className="font-mono font-black text-slate-200 text-base">
                  {finishedPodium[1].officialTimeFormatted}
                </span>
              </div>
            </div>
          )}

          {/* Gold #1 */}
          {finishedPodium[0] && (
            <div
              onClick={() => !isKioskMode && onSelectParticipant(finishedPodium[0])}
              className="bg-gradient-to-b from-amber-950/40 to-slate-900 border-2 border-amber-500/60 rounded-2xl p-6 shadow-2xl cursor-pointer transition flex flex-col justify-between order-1 sm:order-2 scale-105 z-10 relative overflow-hidden"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="w-11 h-11 rounded-xl bg-amber-400 text-slate-950 font-black text-xl flex items-center justify-center shadow-lg shadow-amber-400/30">
                  #1
                </span>
                <span className="text-xs font-black text-amber-400 uppercase tracking-widest flex items-center gap-1">
                  <Medal className="w-4 h-4" /> GOUD
                </span>
              </div>
              <div>
                <span className="text-xl font-black text-white block">
                  {finishedPodium[0].name}
                </span>
                <span className="text-xs text-slate-300">
                  Bib #{finishedPodium[0].bibNumber} • {finishedPodium[0].categoryName}
                </span>
                {finishedPodium[0].club && (
                  <span className="text-[11px] text-slate-400 block italic">
                    {finishedPodium[0].club}
                  </span>
                )}
              </div>
              <div className="mt-4 pt-3 border-t border-amber-500/20 flex items-center justify-between text-xs">
                <span className="text-slate-300">
                  {finishedPodium[0].totalMisses} missers ({finishedPodium[0].penaltyFormatted})
                </span>
                <span className="font-mono font-black text-amber-400 text-xl">
                  {finishedPodium[0].officialTimeFormatted}
                </span>
              </div>
            </div>
          )}

          {/* Bronze #3 */}
          {finishedPodium[2] && (
            <div
              onClick={() => !isKioskMode && onSelectParticipant(finishedPodium[2])}
              className="bg-slate-900 border border-slate-750 hover:border-slate-600 rounded-2xl p-5 shadow cursor-pointer transition flex flex-col justify-between order-3 relative overflow-hidden"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="w-9 h-9 rounded-xl bg-amber-700 text-slate-100 font-black text-base flex items-center justify-center shadow">
                  #3
                </span>
                <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">
                  BRONS
                </span>
              </div>
              <div>
                <span className="text-lg font-bold text-white block">
                  {finishedPodium[2].name}
                </span>
                <span className="text-xs text-slate-400">
                  Bib #{finishedPodium[2].bibNumber} • {finishedPodium[2].categoryName}
                </span>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">
                  {finishedPodium[2].totalMisses} missers ({finishedPodium[2].penaltyFormatted})
                </span>
                <span className="font-mono font-black text-slate-200 text-base">
                  {finishedPodium[2].officialTimeFormatted}
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Main Results Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-850 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                <th className="py-3.5 px-4 w-14 text-center">Pl.</th>
                <th className="py-3.5 px-3 w-16 text-center">Bib</th>
                <th className="py-3.5 px-4">Deelnemer</th>
                <th className="py-3.5 px-4">Categorie</th>
                <th className="py-3.5 px-4">Startgroep</th>
                <th className="py-3.5 px-4 text-center">Schieten (H/M)</th>
                <th className="py-3.5 px-4 text-right">Looptijd (Raw)</th>
                <th className="py-3.5 px-4 text-right">Straf</th>
                <th className="py-3.5 px-4 text-right font-bold text-white">Officiële Tijd</th>
                <th className="py-3.5 px-4 text-right">Verschil</th>
                <th className="py-3.5 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredResults.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-8 text-center text-slate-500 italic">
                    Geen deelnemers gevonden die aan de filters voldoen.
                  </td>
                </tr>
              ) : (
                filteredResults.map((r) => {
                  const isFinished = r.status === 'FINISHED';

                  return (
                    <tr
                      key={`lb-row-${r.participantId}`}
                      onClick={() => !isKioskMode && onSelectParticipant(r)}
                      className="hover:bg-slate-850/80 cursor-pointer transition"
                    >
                      {/* Rank */}
                      <td className="py-3 px-4 text-center font-mono font-bold">
                        {displayRank(r) ? (
                          <span
                            className={`inline-block w-6 h-6 rounded text-xs leading-6 ${
                              displayRank(r) === 1
                                ? 'bg-amber-400 text-slate-950 font-black'
                                : displayRank(r) === 2
                                ? 'bg-slate-300 text-slate-950 font-black'
                                : displayRank(r) === 3
                                ? 'bg-amber-700 text-white font-black'
                                : 'text-slate-400'
                            }`}
                          >
                            {displayRank(r)}
                          </span>
                        ) : (
                          <span className="text-slate-600">-</span>
                        )}
                      </td>

                      {/* Bib */}
                      <td className="py-3 px-3 text-center font-mono font-bold text-amber-400">
                        #{r.bibNumber || '-'}
                      </td>

                      {/* Name + Club */}
                      <td className="py-3 px-4">
                        <span className="font-bold text-white block">{r.name}</span>
                        {r.club && <span className="text-[11px] text-slate-400">{r.club}</span>}
                      </td>

                      {/* Category */}
                      <td className="py-3 px-4 text-slate-300 font-medium">
                        {r.categoryName || '-'}
                      </td>

                      {/* Wave */}
                      <td className="py-3 px-4 text-slate-400">{r.waveName || '-'}</td>

                      {/* Shooting Splits */}
                      <td className="py-3 px-4 text-center">
                        {r.shootingRounds.length === 0 ? (
                          <span className="text-slate-600">-</span>
                        ) : (
                          <div className="flex items-center justify-center gap-1.5 font-mono text-[11px]">
                            {r.shootingRounds.map((sr, sIdx) => (
                              <span
                                key={sr.id ? `sr-pill-${sr.id}` : `sr-pill-${r.participantId}-${sr.round}-${sIdx}`}
                                className={`px-1.5 py-0.5 rounded ${
                                  sr.misses === 0
                                    ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800'
                                    : 'bg-red-950/60 text-red-300 border border-red-800'
                                }`}
                              >
                                {sr.hits}/{sr.shots ?? 5}
                              </span>
                            ))}
                          </div>
                        )}
                      </td>

                      {/* Raw Elapsed */}
                      <td className="py-3 px-4 text-right font-mono text-slate-400">
                        {r.rawElapsedFormatted || '-'}
                      </td>

                      {/* Penalty */}
                      <td className="py-3 px-4 text-right font-mono text-amber-400 font-semibold">
                        {r.totalMisses > 0 ? r.penaltyFormatted : '-'}
                      </td>

                      {/* Official Time */}
                      <td className="py-3 px-4 text-right font-mono font-black text-sm text-emerald-400">
                        {isFinished ? r.officialTimeFormatted : '-'}
                      </td>

                      {/* Gap */}
                      <td className="py-3 px-4 text-right font-mono text-slate-400">
                        {displayGap(r) || '-'}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                            r.status === 'FINISHED'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : r.status === 'STARTED'
                              ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                              : r.status === 'DNF' || r.status === 'DNS' || r.status === 'DSQ'
                              ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {r.resultIssues?.length ? 'VOORLOPIG' : r.status}
                        </span>
                        {r.resultIssues?.map(issue => <span key={issue} className="block text-amber-300 text-xs">{issue}</span>)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
